from django.contrib import admin

from history.models import History
# Register your models here.

admin.site.register(History)