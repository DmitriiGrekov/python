from django.apps import AppConfig


class AchivmentsConfig(AppConfig):
    name = 'achivments'
