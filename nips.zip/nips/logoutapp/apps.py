from django.apps import AppConfig


class LogoutappConfig(AppConfig):
    name = 'logoutapp'
