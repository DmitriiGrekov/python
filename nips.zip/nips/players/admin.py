from django.contrib import admin

from players.models import Players,Comment

# Register your models here.


admin.site.register(Players)
admin.site.register(Comment)
