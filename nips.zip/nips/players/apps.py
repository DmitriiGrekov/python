from django.apps import AppConfig


class PlayersConfig(AppConfig):
    name = 'players'
