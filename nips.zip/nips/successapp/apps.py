from django.apps import AppConfig


class SuccessappConfig(AppConfig):
    name = 'successapp'
